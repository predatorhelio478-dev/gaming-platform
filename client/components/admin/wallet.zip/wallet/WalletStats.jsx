"use client";

import {
    Wallet,
    TrendingUp,
    TrendingDown,
    Trophy,
    LockKeyhole,
} from "lucide-react";


// ======================================================
// WALLET STATS
// ======================================================

export default function WalletStats({
    stats = {},
}) {

    // ==================================================
    // SAFE NUMBER
    // ==================================================

    const number = (value) => {

        const parsed =
            Number(value);

        return Number.isFinite(parsed)
            ? parsed
            : 0;

    };


    // ==================================================
    // CURRENCY
    // ==================================================

    const formatCurrency = (value) => {

        return new Intl.NumberFormat(
            "en-IN",
            {
                style: "currency",
                currency: "INR",
                maximumFractionDigits: 2,
            }
        ).format(
            number(value)
        );

    };


    // ==================================================
    // STATS
    // ==================================================

    const totalBalance =
        number(
            stats?.totalBalance ??
            stats?.balance ??
            0
        );


    const totalWinningBalance =
        number(
            stats?.totalWinningBalance ??
            stats?.winningBalance ??
            0
        );


    const totalDeposits =
        number(
            stats?.totalDeposit ??
            stats?.totalDeposits ??
            0
        );


    const totalWithdrawals =
        number(
            stats?.totalWithdraw ??
            stats?.totalWithdrawals ??
            0
        );


    const totalLockedBalance =
        number(
            stats?.totalLockedBalance ??
            stats?.lockedBalance ??
            0
        );


    // ==================================================
    // CARDS
    // ==================================================

    const cards = [

        {
            title:
                "Total Balance",

            value:
                formatCurrency(
                    totalBalance
                ),

            description:
                "All users wallet balance",

            icon:
                Wallet,

            iconClass:
                "text-emerald-400",

            iconBg:
                "bg-emerald-500/10",

        },

        {
            title:
                "Winning Balance",

            value:
                formatCurrency(
                    totalWinningBalance
                ),

            description:
                "Total winning funds",

            icon:
                Trophy,

            iconClass:
                "text-yellow-400",

            iconBg:
                "bg-yellow-500/10",

        },

        {
            title:
                "Total Deposits",

            value:
                formatCurrency(
                    totalDeposits
                ),

            description:
                "All successful deposits",

            icon:
                TrendingUp,

            iconClass:
                "text-blue-400",

            iconBg:
                "bg-blue-500/10",

        },

        {
            title:
                "Total Withdrawals",

            value:
                formatCurrency(
                    totalWithdrawals
                ),

            description:
                "All withdrawal requests",

            icon:
                TrendingDown,

            iconClass:
                "text-red-400",

            iconBg:
                "bg-red-500/10",

        },

        {
            title:
                "Locked Balance",

            value:
                formatCurrency(
                    totalLockedBalance
                ),

            description:
                "Currently locked funds",

            icon:
                LockKeyhole,

            iconClass:
                "text-purple-400",

            iconBg:
                "bg-purple-500/10",

        },

    ];


    // ==================================================
    // RENDER
    // ==================================================

    return (

        <section
            className="
                mt-6
                grid
                min-w-0
                grid-cols-1
                gap-3
                sm:grid-cols-2
                lg:grid-cols-3
                xl:grid-cols-4
                2xl:grid-cols-5
            "
        >

            {cards.map(
                (card) => {

                    const Icon =
                        card.icon;


                    return (

                        <div
                            key={
                                card.title
                            }
                            className="
                                min-w-0
                                rounded-2xl
                                border
                                border-white/[0.06]
                                bg-[#0d101d]
                                p-4
                                shadow-xl
                                transition
                                duration-200
                                hover:border-white/[0.10]
                            "
                        >

                            {/* ======================================
                                TOP
                            ====================================== */}

                            <div
                                className="
                                    flex
                                    items-start
                                    justify-between
                                    gap-3
                                "
                            >

                                <div
                                    className="
                                        min-w-0
                                    "
                                >

                                    <p
                                        className="
                                            truncate
                                            text-xs
                                            font-medium
                                            text-slate-500
                                        "
                                    >

                                        {
                                            card.title
                                        }

                                    </p>


                                    <p
                                        className="
                                            mt-2
                                            truncate
                                            text-xl
                                            font-black
                                            tracking-tight
                                            text-white
                                        "
                                    >

                                        {
                                            card.value
                                        }

                                    </p>

                                </div>


                                {/* ICON */}

                                <div
                                    className={`
                                        flex
                                        h-10
                                        w-10
                                        shrink-0
                                        items-center
                                        justify-center
                                        rounded-xl
                                        ${card.iconBg}
                                        ${card.iconClass}
                                    `}
                                >

                                    <Icon
                                        size={
                                            19
                                        }
                                        strokeWidth={
                                            1.8
                                        }
                                    />

                                </div>

                            </div>


                            {/* ======================================
                                DESCRIPTION
                            ====================================== */}

                            <p
                                className="
                                    mt-3
                                    truncate
                                    text-[11px]
                                    text-slate-600
                                "
                            >

                                {
                                    card.description
                                }

                            </p>

                        </div>

                    );

                }
            )}

        </section>

    );

}