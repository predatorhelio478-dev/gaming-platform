"use client";

import {
    Search,
    RotateCcw,
    SlidersHorizontal,
    CalendarDays,
    X,
} from "lucide-react";


// ======================================================
// WALLET FILTERS
// ======================================================

export default function WalletFilters({

    search = "",
    setSearch,

    walletStatus = "all",
    setWalletStatus,

    transactionType = "all",
    setTransactionType,

    dateFrom = "",
    setDateFrom,

    dateTo = "",
    setDateTo,

    minBalance = "",
    setMinBalance,

    maxBalance = "",
    setMaxBalance,

    onReset,

}) {

    // ==================================================
    // SEARCH CHANGE
    // ==================================================

    const handleSearchChange = (event) => {

        if (typeof setSearch === "function") {

            setSearch(
                event.target.value
            );

        }

    };


    // ==================================================
    // STATUS CHANGE
    // ==================================================

    const handleStatusChange = (event) => {

        if (typeof setWalletStatus === "function") {

            setWalletStatus(
                event.target.value
            );

        }

    };


    // ==================================================
    // TRANSACTION TYPE CHANGE
    // ==================================================

    const handleTransactionTypeChange = (event) => {

        if (typeof setTransactionType === "function") {

            setTransactionType(
                event.target.value
            );

        }

    };


    // ==================================================
    // DATE FROM
    // ==================================================

    const handleDateFromChange = (event) => {

        if (typeof setDateFrom === "function") {

            setDateFrom(
                event.target.value
            );

        }

    };


    // ==================================================
    // DATE TO
    // ==================================================

    const handleDateToChange = (event) => {

        if (typeof setDateTo === "function") {

            setDateTo(
                event.target.value
            );

        }

    };


    // ==================================================
    // MIN BALANCE
    // ==================================================

    const handleMinBalanceChange = (event) => {

        if (typeof setMinBalance === "function") {

            setMinBalance(
                event.target.value
            );

        }

    };


    // ==================================================
    // MAX BALANCE
    // ==================================================

    const handleMaxBalanceChange = (event) => {

        if (typeof setMaxBalance === "function") {

            setMaxBalance(
                event.target.value
            );

        }

    };


    // ==================================================
    // RESET
    // ==================================================

    const handleReset = () => {

        if (typeof onReset === "function") {

            onReset();

        }

    };


    // ==================================================
    // HAS ACTIVE FILTER
    // ==================================================

    const hasActiveFilters =
        Boolean(
            search ||
            walletStatus !== "all" ||
            transactionType !== "all" ||
            dateFrom ||
            dateTo ||
            minBalance ||
            maxBalance
        );


    // ==================================================
    // CLEAR SEARCH
    // ==================================================

    const handleClearSearch = () => {

        if (typeof setSearch === "function") {

            setSearch("");

        }

    };


    // ==================================================
    // RENDER
    // ==================================================

    return (

        <section
            className="
                mt-6
                overflow-hidden
                rounded-2xl
                border
                border-white/[0.06]
                bg-[#0d101d]
            "
        >

            {/* ==================================================
                FILTER HEADER
            ================================================== */}

            <div
                className="
                    flex
                    flex-col
                    gap-3
                    border-b
                    border-white/[0.05]
                    px-4
                    py-4
                    sm:px-5
                    lg:flex-row
                    lg:items-center
                    lg:justify-between
                "
            >

                <div
                    className="
                        flex
                        items-center
                        gap-3
                    "
                >

                    <div
                        className="
                            flex
                            h-9
                            w-9
                            shrink-0
                            items-center
                            justify-center
                            rounded-xl
                            bg-violet-500/10
                            text-violet-400
                        "
                    >

                        <SlidersHorizontal
                            size={17}
                        />

                    </div>


                    <div>

                        <h3
                            className="
                                text-sm
                                font-bold
                                text-white
                            "
                        >

                            Wallet Filters

                        </h3>


                        <p
                            className="
                                mt-0.5
                                text-[11px]
                                text-slate-600
                            "
                        >

                            Search and filter wallet activity

                        </p>

                    </div>

                </div>


                {/* RESET */}

                {hasActiveFilters && (

                    <button
                        type="button"
                        onClick={
                            handleReset
                        }
                        className="
                            flex
                            w-fit
                            items-center
                            gap-2
                            rounded-lg
                            border
                            border-white/[0.07]
                            bg-white/[0.025]
                            px-3
                            py-2
                            text-xs
                            font-semibold
                            text-slate-400
                            transition
                            hover:border-violet-500/20
                            hover:bg-violet-500/[0.06]
                            hover:text-violet-300
                        "
                    >

                        <RotateCcw
                            size={13}
                        />

                        Reset Filters

                    </button>

                )}

            </div>


            {/* ==================================================
                FILTER BODY
            ================================================== */}

            <div
                className="
                    p-4
                    sm:p-5
                "
            >

                <div
                    className="
                        grid
                        gap-3
                        sm:grid-cols-2
                        lg:grid-cols-3
                        xl:grid-cols-4
                    "
                >

                    {/* ==================================================
                        SEARCH
                    ================================================== */}

                    <div
                        className="
                            sm:col-span-2
                            lg:col-span-2
                            xl:col-span-2
                        "
                    >

                        <label
                            className="
                                mb-2
                                block
                                text-[11px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-slate-600
                            "
                        >

                            Search User

                        </label>


                        <div
                            className="
                                flex
                                h-11
                                items-center
                                overflow-hidden
                                rounded-xl
                                border
                                border-white/[0.07]
                                bg-[#080b15]
                                transition
                                focus-within:border-violet-500/40
                            "
                        >

                            <span
                                className="
                                    pl-3
                                    text-slate-600
                                "
                            >

                                <Search
                                    size={16}
                                />

                            </span>


                            <input
                                type="text"
                                value={
                                    search
                                }
                                onChange={
                                    handleSearchChange
                                }
                                placeholder="Name, username, email or user ID"
                                className="
                                    min-w-0
                                    flex-1
                                    bg-transparent
                                    px-3
                                    text-sm
                                    text-white
                                    outline-none
                                    placeholder:text-slate-700
                                "
                            />


                            {search && (

                                <button
                                    type="button"
                                    onClick={
                                        handleClearSearch
                                    }
                                    className="
                                        mr-2
                                        flex
                                        h-7
                                        w-7
                                        items-center
                                        justify-center
                                        rounded-lg
                                        text-slate-600
                                        transition
                                        hover:bg-white/[0.05]
                                        hover:text-slate-300
                                    "
                                    aria-label="Clear search"
                                >

                                    <X
                                        size={14}
                                    />

                                </button>

                            )}

                        </div>

                    </div>


                    {/* ==================================================
                        WALLET STATUS
                    ================================================== */}

                    <div>

                        <label
                            className="
                                mb-2
                                block
                                text-[11px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-slate-600
                            "
                        >

                            Wallet Status

                        </label>


                        <select
                            value={
                                walletStatus
                            }
                            onChange={
                                handleStatusChange
                            }
                            className="
                                h-11
                                w-full
                                cursor-pointer
                                rounded-xl
                                border
                                border-white/[0.07]
                                bg-[#080b15]
                                px-3
                                text-sm
                                text-slate-300
                                outline-none
                                transition
                                focus:border-violet-500/40
                            "
                        >

                            <option
                                value="all"
                            >
                                All Wallets
                            </option>

                            <option
                                value="active"
                            >
                                Active
                            </option>

                            <option
                                value="positive"
                            >
                                Positive Balance
                            </option>

                            <option
                                value="zero"
                            >
                                Zero Balance
                            </option>

                            <option
                                value="locked"
                            >
                                Has Locked Balance
                            </option>

                        </select>

                    </div>


                    {/* ==================================================
                        TRANSACTION TYPE
                    ================================================== */}

                    <div>

                        <label
                            className="
                                mb-2
                                block
                                text-[11px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-slate-600
                            "
                        >

                            Transaction Type

                        </label>


                        <select
                            value={
                                transactionType
                            }
                            onChange={
                                handleTransactionTypeChange
                            }
                            className="
                                h-11
                                w-full
                                cursor-pointer
                                rounded-xl
                                border
                                border-white/[0.07]
                                bg-[#080b15]
                                px-3
                                text-sm
                                text-slate-300
                                outline-none
                                transition
                                focus:border-violet-500/40
                            "
                        >

                            <option
                                value="all"
                            >
                                All Transactions
                            </option>

                            <option
                                value="deposit"
                            >
                                Deposit
                            </option>

                            <option
                                value="withdraw"
                            >
                                Withdrawal
                            </option>

                            <option
                                value="bet"
                            >
                                Bet
                            </option>

                            <option
                                value="win"
                            >
                                Win
                            </option>

                            <option
                                value="refund"
                            >
                                Refund
                            </option>

                            <option
                                value="bonus"
                            >
                                Bonus
                            </option>

                            <option
                                value="admin_credit"
                            >
                                Admin Credit
                            </option>

                            <option
                                value="admin_debit"
                            >
                                Admin Debit
                            </option>

                        </select>

                    </div>


                    {/* ==================================================
                        FROM DATE
                    ================================================== */}

                    <div>

                        <label
                            className="
                                mb-2
                                block
                                text-[11px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-slate-600
                            "
                        >

                            From Date

                        </label>


                        <div
                            className="
                                flex
                                h-11
                                items-center
                                rounded-xl
                                border
                                border-white/[0.07]
                                bg-[#080b15]
                                px-3
                                transition
                                focus-within:border-violet-500/40
                            "
                        >

                            <CalendarDays
                                size={15}
                                className="
                                    mr-2
                                    shrink-0
                                    text-slate-600
                                "
                            />


                            <input
                                type="date"
                                value={
                                    dateFrom
                                }
                                onChange={
                                    handleDateFromChange
                                }
                                className="
                                    min-w-0
                                    flex-1
                                    bg-transparent
                                    text-sm
                                    text-slate-300
                                    outline-none
                                    [color-scheme:dark]
                                "
                            />

                        </div>

                    </div>


                    {/* ==================================================
                        TO DATE
                    ================================================== */}

                    <div>

                        <label
                            className="
                                mb-2
                                block
                                text-[11px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-slate-600
                            "
                        >

                            To Date

                        </label>


                        <div
                            className="
                                flex
                                h-11
                                items-center
                                rounded-xl
                                border
                                border-white/[0.07]
                                bg-[#080b15]
                                px-3
                                transition
                                focus-within:border-violet-500/40
                            "
                        >

                            <CalendarDays
                                size={15}
                                className="
                                    mr-2
                                    shrink-0
                                    text-slate-600
                                "
                            />


                            <input
                                type="date"
                                value={
                                    dateTo
                                }
                                onChange={
                                    handleDateToChange
                                }
                                className="
                                    min-w-0
                                    flex-1
                                    bg-transparent
                                    text-sm
                                    text-slate-300
                                    outline-none
                                    [color-scheme:dark]
                                "
                            />

                        </div>

                    </div>


                    {/* ==================================================
                        MIN BALANCE
                    ================================================== */}

                    <div>

                        <label
                            className="
                                mb-2
                                block
                                text-[11px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-slate-600
                            "
                        >

                            Min Balance

                        </label>


                        <div
                            className="
                                flex
                                h-11
                                items-center
                                overflow-hidden
                                rounded-xl
                                border
                                border-white/[0.07]
                                bg-[#080b15]
                                transition
                                focus-within:border-violet-500/40
                            "
                        >

                            <span
                                className="
                                    px-3
                                    text-slate-600
                                "
                            >

                                ₹

                            </span>


                            <input
                                type="number"
                                min="0"
                                value={
                                    minBalance
                                }
                                onChange={
                                    handleMinBalanceChange
                                }
                                placeholder="0"
                                className="
                                    min-w-0
                                    flex-1
                                    bg-transparent
                                    pr-3
                                    text-sm
                                    text-white
                                    outline-none
                                    placeholder:text-slate-700
                                "
                            />

                        </div>

                    </div>


                    {/* ==================================================
                        MAX BALANCE
                    ================================================== */}

                    <div>

                        <label
                            className="
                                mb-2
                                block
                                text-[11px]
                                font-semibold
                                uppercase
                                tracking-wider
                                text-slate-600
                            "
                        >

                            Max Balance

                        </label>


                        <div
                            className="
                                flex
                                h-11
                                items-center
                                overflow-hidden
                                rounded-xl
                                border
                                border-white/[0.07]
                                bg-[#080b15]
                                transition
                                focus-within:border-violet-500/40
                            "
                        >

                            <span
                                className="
                                    px-3
                                    text-slate-600
                                "
                            >

                                ₹

                            </span>


                            <input
                                type="number"
                                min="0"
                                value={
                                    maxBalance
                                }
                                onChange={
                                    handleMaxBalanceChange
                                }
                                placeholder="Unlimited"
                                className="
                                    min-w-0
                                    flex-1
                                    bg-transparent
                                    pr-3
                                    text-sm
                                    text-white
                                    outline-none
                                    placeholder:text-slate-700
                                "
                            />

                        </div>

                    </div>

                </div>


                {/* ==================================================
                    ACTIVE FILTER INDICATOR
                ================================================== */}

                {hasActiveFilters && (

                    <div
                        className="
                            mt-4
                            flex
                            items-center
                            gap-2
                            text-[10px]
                            text-slate-600
                        "
                    >

                        <span
                            className="
                                h-1.5
                                w-1.5
                                rounded-full
                                bg-violet-400
                            "
                        />

                        Filters are active

                    </div>

                )}

            </div>

        </section>

    );

}