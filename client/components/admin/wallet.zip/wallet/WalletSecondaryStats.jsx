"use client";

import {
    Users,
    CircleDollarSign,
    Trophy,
    Gift,
    Activity,
} from "lucide-react";


// ======================================================
// WALLET SECONDARY STATS
// ======================================================

export default function WalletSecondaryStats({
    stats = {},
}) {

    // ==================================================
    // SAFE NUMBER
    // ==================================================

    const number = (value) => {

        const parsed =
            Number(value);

        return Number.isFinite(parsed)
            ? parsed
            : 0;

    };


    // ==================================================
    // CURRENCY
    // ==================================================

    const formatCurrency = (value) => {

        return new Intl.NumberFormat(
            "en-IN",
            {
                style: "currency",
                currency: "INR",
                maximumFractionDigits: 2,
            }
        ).format(
            number(value)
        );

    };


    // ==================================================
    // VALUES
    // ==================================================

    const totalUsers =
        number(
            stats?.totalUsers ??
            stats?.users ??
            0
        );


    const usersWithBalance =
        number(
            stats?.usersWithBalance ??
            stats?.fundedUsers ??
            0
        );


    const totalBet =
        number(
            stats?.totalBet ??
            stats?.totalBets ??
            0
        );


    const totalWin =
        number(
            stats?.totalWin ??
            stats?.totalWins ??
            0
        );


    const totalBonus =
        number(
            stats?.totalBonus ??
            stats?.bonusBalance ??
            0
        );


    // ==================================================
    // CARDS
    // ==================================================

    const cards = [

        {
            title:
                "Total Users",

            value:
                totalUsers.toLocaleString(
                    "en-IN"
                ),

            description:
                "Registered platform users",

            icon:
                Users,

            iconClass:
                "text-cyan-400",

            iconBg:
                "bg-cyan-500/10",

        },

        {
            title:
                "Users With Balance",

            value:
                usersWithBalance.toLocaleString(
                    "en-IN"
                ),

            description:
                "Users holding wallet funds",

            icon:
                Activity,

            iconClass:
                "text-emerald-400",

            iconBg:
                "bg-emerald-500/10",

        },

        {
            title:
                "Total Bet",

            value:
                formatCurrency(
                    totalBet
                ),

            description:
                "Total amount wagered",

            icon:
                CircleDollarSign,

            iconClass:
                "text-orange-400",

            iconBg:
                "bg-orange-500/10",

        },

        {
            title:
                "Total Win",

            value:
                formatCurrency(
                    totalWin
                ),

            description:
                "Total winning payouts",

            icon:
                Trophy,

            iconClass:
                "text-yellow-400",

            iconBg:
                "bg-yellow-500/10",

        },

        {
            title:
                "Bonus Balance",

            value:
                formatCurrency(
                    totalBonus
                ),

            description:
                "Total bonus funds",

            icon:
                Gift,

            iconClass:
                "text-pink-400",

            iconBg:
                "bg-pink-500/10",

        },

    ];


    // ==================================================
    // RENDER
    // ==================================================

    return (

        <section
            className="
                mt-3
                grid
                min-w-0
                grid-cols-1
                gap-3
                sm:grid-cols-2
                lg:grid-cols-3
                xl:grid-cols-4
                2xl:grid-cols-5
            "
        >

            {cards.map(
                (card) => {

                    const Icon =
                        card.icon;


                    return (

                        <div
                            key={
                                card.title
                            }
                            className="
                                min-w-0
                                rounded-2xl
                                border
                                border-white/[0.05]
                                bg-[#0a0e1a]
                                p-4
                                transition
                                duration-200
                                hover:border-white/[0.10]
                                hover:bg-[#0d111f]
                            "
                        >

                            {/* ======================================
                                HEADER
                            ====================================== */}

                            <div
                                className="
                                    flex
                                    items-center
                                    justify-between
                                    gap-3
                                "
                            >

                                <div
                                    className="
                                        min-w-0
                                    "
                                >

                                    <p
                                        className="
                                            truncate
                                            text-[11px]
                                            font-semibold
                                            uppercase
                                            tracking-wider
                                            text-slate-600
                                        "
                                    >

                                        {
                                            card.title
                                        }

                                    </p>


                                    <p
                                        className="
                                            mt-2
                                            truncate
                                            text-lg
                                            font-black
                                            text-white
                                        "
                                    >

                                        {
                                            card.value
                                        }

                                    </p>

                                </div>


                                {/* ==================================
                                    ICON
                                ================================== */}

                                <div
                                    className={`
                                        flex
                                        h-9
                                        w-9
                                        shrink-0
                                        items-center
                                        justify-center
                                        rounded-xl
                                        ${card.iconBg}
                                        ${card.iconClass}
                                    `}
                                >

                                    <Icon
                                        size={
                                            17
                                        }
                                        strokeWidth={
                                            1.8
                                        }
                                    />

                                </div>

                            </div>


                            {/* ======================================
                                DESCRIPTION
                            ====================================== */}

                            <p
                                className="
                                    mt-3
                                    truncate
                                    text-[10px]
                                    text-slate-700
                                "
                            >

                                {
                                    card.description
                                }

                            </p>

                        </div>

                    );

                }
            )}

        </section>

    );

}